#!/bin/bash
if [ -f "/home/baiyu/miniconda3/etc/profile.d/conda.sh" ]; then
    . "/home/baiyu/miniconda3/etc/profile.d/conda.sh"
 else
     export PATH="/home/baiyu/miniconda3/bin:$PATH"
 fi
conda activate azalea

azalea-play ./models/checkpoint.105000.policy.pth

